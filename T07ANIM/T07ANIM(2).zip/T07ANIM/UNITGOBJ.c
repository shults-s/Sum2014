/* FILENAME: UNITGOBJ.C
 * PROGRAMMER: SS3
 * PURPOSE: Animation unit samples handle module.
 * LAST UPDATE: 13.06.2014
 */

#include <string.h>
#include <stdlib.h>

#include "anim.h"
#include "vec.h"
//#pragma warning(disable: 4244 4305)

/* Unit for geometric object data type */
typedef struct tagss3UNIT_GOBJ
{
  SS3_UNIT_BASE_FIELDS;  /* Base fields of unit */
  ss3GEOM *Obj;           /* Geometric object */
} ss3UNIT_GOBJ;

ss3CAMERA SS3_RndCam;

/* Init geometric unit of animation function.
 * ARGUMENTS:
 *   - pointer for animation:
 *       ss3UNIT *Unit;
 *   - pointer to animation:
 *       ss3ANIM *Ani;
 * RETURNS: None.
 */
static VOID SS3_GObjUnitInit( ss3UNIT_GOBJ *Unit, ss3ANIM *Ani )
{
  if ((Unit->Obj = malloc(sizeof(ss3GEOM))) == NULL)
    return;
  //SS3_GeomLoad(&Unit->Obj[0], "Z:\\SUM2014\\T07ANIM\\x6\\x6.object");
  //SS3_RndGObjLoad(&Unit->Obj[1], "avent.object");
  SS3_GeomLoad(&Unit->Obj[0], "avent.object");
} /* End of 'SS3_GobjUnitInit' function */

/* Close geometric unit of animation function.
 * ARGUMENTS:
 *   - pointer for animation:
 *       ss3UNIT *Unit;
 *   - pointer to animation:
 *       ss3ANIM *Ani;
 * RETURNS: None.
 */
static VOID SS3_GObjUnitClose( ss3UNIT_GOBJ *Unit, ss3ANIM *Ani )
{
  SS3_GeomFree(&Unit->Obj[0]);
} /* End of 'SS3_GobjUnitClose' function */

/* Response geometric unit of animation function.
 * ARGUMENTS:
 *   - pointer for animation:
 *       ss3UNIT *Unit;
 *   - pointer to animation:
 *       ss3ANIM *Ani;
 * RETURNS: None.
 */
static VOID SS3_GObjUnitResponse( ss3UNIT_GOBJ *Unit, ss3ANIM *Ani )
{
} /* End of 'SS3_GobjUnitResponse' function */

/* Render unit of animation function.
 * ARGUMENTS:
 *   - pointer for animation:
 *       ss3UNIT *Unit;
 *   - pointer to animation:
 *       ss3ANIM *Ani;
 * RETURNS: None.
 */
static VOID SS3_GObjUnitRender( ss3UNIT_GOBJ *Unit, ss3ANIM *Ani )
{

  MATR WVP;
  static DBL time;

  /* ��� � ������� ����������� */
  Ani->MatrWorld = MatrIdentity();
  Ani->MatrView =
    MatrViewLookAt(
    MatrMultVec(MatrRotateY(Ani->JR * 90), MatrMultVec(MatrRotateZ(Ani->JY * 90), Ani->PosCam)),
      VecSet(0, 0, 0), VecSet(0, 1, 0));
  WVP = MatrMult4x4(SS3_Anim.MatrWorld, MatrMult4x4(SS3_Anim.MatrView, SS3_Anim.MatrProjection));
  glLoadMatrixf(WVP.A[0]);

  glLineWidth(3);

  /* ������ ��������� */
  time += Ani->GlobalDeltaTime;
  if (time > 1)
  {
    time = 0;
    SS3_ShadProgClose(SS3_ShaderProg);
    SS3_ShaderProg = SS3_ShadProgInit("a.vert", "a.frag");
  }


  glLineWidth(1);
  if (Ani->Keys['Q'])
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
  else
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

  Ani->MatrWorld = MatrRotateY(Ani->Time * 30);
  Ani->MatrWorld = MatrMult4x4(MatrRotateX(-90), Ani->MatrWorld);
  glEnable(GL_DEPTH_TEST);
  SS3_GeomDraw(&Unit->Obj[0]);
  glUseProgram(0);

} /* End of 'SS3_GobjUnitRender' function */

/* Create geometric unit of animation function.
 * ARGUMENTS: None.
 * RETURNS:
 *   (ss3UNIT *) pointer to new unit.
 */
ss3UNIT * SS3_GObjUnitCreate( VOID )
{
  ss3UNIT_GOBJ *Unit;

  if ((Unit = (ss3UNIT_GOBJ *)SS3_AnimUnitCreate(sizeof(ss3UNIT_GOBJ))) == NULL)
    return NULL;
  /* create default unit */
  Unit->Init = (VOID *)SS3_GObjUnitInit;
  Unit->Close = (VOID *)SS3_GObjUnitClose;
  Unit->Response = (VOID *)SS3_GObjUnitResponse;
  Unit->Render = (VOID *)SS3_GObjUnitRender;
  return (ss3UNIT *)Unit;
} /* End of 'SS3_GobjUnitCreate' function */

/* END OF 'UNITGOBJ.C' FILE */